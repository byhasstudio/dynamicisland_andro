package com.byhas.dynamicisland

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.FloatPropertyCompat
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

data class IslandInfo(
    val title: String,
    val text: String,
    val icon: Drawable?,
    val intent: PendingIntent?
)

class IslandService : Service() {

    companion object {
        @Volatile
        var instance: IslandService? = null
        const val ACTION_RELOAD = "com.byhas.dynamicisland.RELOAD"
        const val ACTION_TEST = "com.byhas.dynamicisland.TEST"
        private const val CHANNEL = "island_service"
        private const val SHOW_MS = 4500L
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private var island: FrameLayout? = null
    private lateinit var content: LinearLayout
    private lateinit var iconView: ImageView
    private lateinit var titleView: TextView
    private lateinit var textView: TextView

    private val bg = GradientDrawable()
    private var cW = 0
    private var cH = 0
    private var eW = 0
    private var eH = 0
    private var expanded = false
    private var current: IslandInfo? = null
    private var wAnim: SpringAnimation? = null
    private var hAnim: SpringAnimation? = null
    private val collapseRunnable = Runnable { collapse() }

    private val propW = object : FloatPropertyCompat<View>("islandW") {
        override fun getValue(v: View): Float = v.layoutParams.width.toFloat()
        override fun setValue(v: View, value: Float) {
            val lp = v.layoutParams
            lp.width = value.toInt().coerceAtLeast(1)
            v.layoutParams = lp
        }
    }

    private val propH = object : FloatPropertyCompat<View>("islandH") {
        override fun getValue(v: View): Float = v.layoutParams.height.toFloat()
        override fun setValue(v: View, value: Float) {
            val lp = v.layoutParams
            lp.height = value.toInt().coerceAtLeast(1)
            v.layoutParams = lp
            bg.cornerRadius = minOf(lp.height / 2f, dp(26).toFloat())
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        try {
            build()
        } catch (e: Exception) {
            // Izin overlay belum diberikan.
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RELOAD -> {
                destroyView()
                try { build() } catch (e: Exception) { stopSelf() }
            }
            ACTION_TEST -> show(IslandInfo("Dynamic Island", "Animasi spring berjalan lancar", null, null))
        }
        return START_STICKY
    }

    override fun onDestroy() {
        destroyView()
        instance = null
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Dynamic Island", NotificationManager.IMPORTANCE_MIN)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Dynamic Island aktif")
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    /** Warna pastel semi-transparan: gradasi atas lebih terang + garis tepi putih tipis (efek kaca). */
    private fun applyStyle(p: Prefs) {
        val base = p.bgColor
        val a = p.opacity.coerceIn(40, 100) * 255 / 100
        val top = ColorUtils.setAlphaComponent(ColorUtils.blendARGB(base, Color.WHITE, 0.30f), a)
        val bottom = ColorUtils.setAlphaComponent(base, a)
        bg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM)
        bg.setColors(intArrayOf(top, bottom))
        bg.setStroke(dp(1), ColorUtils.setAlphaComponent(Color.WHITE, 110))

        val lightBg = ColorUtils.calculateLuminance(base) > 0.5
        titleView.setTextColor(if (lightBg) Color.parseColor("#1C1C1E") else Color.WHITE)
        textView.setTextColor(if (lightBg) Color.parseColor("#55555C") else Color.parseColor("#D0D0D6"))
    }

    private fun build() {
        val p = Prefs(this)
        cW = dp(p.collapsedW)
        cH = dp(32)
        eW = dp(p.expandedW)
        eH = dp(76)
        expanded = false
        bg.cornerRadius = cH / 2f

        iconView = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(11).toFloat())
                }
            }
        }
        titleView = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        textView = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { marginStart = dp(12) }
            addView(titleView)
            addView(textView)
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
            alpha = 0f
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            addView(iconView)
            addView(col)
        }
        applyStyle(p)

        val isl = FrameLayout(this).apply {
            background = bg
            layoutParams = FrameLayout.LayoutParams(cW, cH, Gravity.CENTER_HORIZONTAL)
            addView(content)
            setOnClickListener { onTap() }
        }
        island = isl
        val r = FrameLayout(this).apply { addView(isl) }
        root = r

        wAnim = SpringAnimation(isl, propW, cW.toFloat()).apply {
            spring.setDampingRatio(0.58f).setStiffness(340f)
        }
        hAnim = SpringAnimation(isl, propH, cH.toFloat()).apply {
            spring.setDampingRatio(0.68f).setStiffness(380f)
        }

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(p.topOffset)
        }
        wm.addView(r, lp)
    }

    private fun destroyView() {
        main.removeCallbacks(collapseRunnable)
        wAnim?.cancel()
        hAnim?.cancel()
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        island = null
    }

    fun show(info: IslandInfo) {
        main.post {
            if (root == null) return@post
            current = info
            titleView.text = info.title
            textView.text = info.text
            iconView.setImageDrawable(info.icon)
            iconView.visibility = if (info.icon == null) View.GONE else View.VISIBLE
            expand()
            main.removeCallbacks(collapseRunnable)
            main.postDelayed(collapseRunnable, SHOW_MS)
        }
    }

    private fun expand() {
        expanded = true
        wAnim?.animateToFinalPosition(eW.toFloat())
        hAnim?.animateToFinalPosition(eH.toFloat())
        content.animate().cancel()
        content.translationY = -dp(6).toFloat()
        content.animate()
            .alpha(1f).translationY(0f)
            .setStartDelay(110).setDuration(260)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    private fun collapse() {
        expanded = false
        main.removeCallbacks(collapseRunnable)
        content.animate().cancel()
        content.animate()
            .alpha(0f).translationY(-dp(4).toFloat())
            .setStartDelay(0).setDuration(130)
            .start()
        wAnim?.animateToFinalPosition(cW.toFloat())
        hAnim?.animateToFinalPosition(cH.toFloat())
    }

    private fun onTap() {
        if (expanded) {
            try { current?.intent?.send() } catch (_: Exception) {}
            collapse()
        } else if (current != null) {
            expand()
            main.postDelayed(collapseRunnable, SHOW_MS)
        }
    }
}
