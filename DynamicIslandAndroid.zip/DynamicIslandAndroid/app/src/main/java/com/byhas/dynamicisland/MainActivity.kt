package com.byhas.dynamicisland

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject

/**
 * Halaman pengaturan = app/src/main/assets/index.html, ditampilkan di WebView.
 * HTML memanggil fungsi native lewat objek `Android` (lihat class Bridge).
 */
class MainActivity : Activity() {

    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    inner class Bridge {
        private val prefs = Prefs(this@MainActivity)

        @JavascriptInterface
        fun getState(): String = JSONObject().apply {
            put("overlay", Settings.canDrawOverlays(this@MainActivity))
            put("listener", NotificationManagerCompat
                .getEnabledListenerPackages(this@MainActivity).contains(packageName))
            put("running", IslandService.instance != null)
            put("top", prefs.topOffset)
            put("cw", prefs.collapsedW)
            put("ew", prefs.expandedW)
            put("op", prefs.opacity)
            put("color", String.format("#%06X", 0xFFFFFF and prefs.bgColor))
        }.toString()

        @JavascriptInterface
        fun openOverlay() = runOnUiThread {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }

        @JavascriptInterface
        fun openListener() = runOnUiThread {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        @JavascriptInterface
        fun requestNotif() = runOnUiThread {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }

        @JavascriptInterface
        fun toggle() = runOnUiThread {
            if (IslandService.instance != null) {
                stopService(Intent(this@MainActivity, IslandService::class.java))
            } else if (!Settings.canDrawOverlays(this@MainActivity)) {
                Toast.makeText(this@MainActivity, "Berikan izin overlay dulu", Toast.LENGTH_SHORT).show()
            } else {
                startForegroundService(Intent(this@MainActivity, IslandService::class.java))
            }
        }

        @JavascriptInterface
        fun test() = runOnUiThread {
            if (IslandService.instance != null) {
                startService(
                    Intent(this@MainActivity, IslandService::class.java)
                        .setAction(IslandService.ACTION_TEST)
                )
            } else {
                Toast.makeText(this@MainActivity, "Nyalakan Dynamic Island dulu", Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface
        fun setValue(key: String, v: Int) {
            when (key) {
                "top" -> prefs.topOffset = v
                "cw" -> prefs.collapsedW = v
                "ew" -> prefs.expandedW = v
                "op" -> prefs.opacity = v
            }
        }

        @JavascriptInterface
        fun setColor(hex: String) {
            try {
                prefs.bgColor = Color.parseColor(hex) or (0xFF shl 24)
            } catch (_: Exception) {
            }
        }

        @JavascriptInterface
        fun reload() = runOnUiThread {
            if (IslandService.instance != null) {
                startService(
                    Intent(this@MainActivity, IslandService::class.java)
                        .setAction(IslandService.ACTION_RELOAD)
                )
            }
        }
    }
}
