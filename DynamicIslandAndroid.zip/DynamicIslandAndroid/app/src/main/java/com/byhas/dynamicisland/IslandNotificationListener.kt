package com.byhas.dynamicisland

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class IslandNotificationListener : NotificationListenerService() {

    private var lastSig = ""
    private var lastTime = 0L

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val isMedia = n.category == Notification.CATEGORY_TRANSPORT
        val isOngoing = n.flags and Notification.FLAG_ONGOING_EVENT != 0
        val isTimer = n.category == Notification.CATEGORY_ALARM || n.category == "stopwatch"
        // Notifikasi ongoing biasa (download, dll) dilewati supaya tidak spam.
        if (isOngoing && !isMedia && !isTimer) return

        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = (ex.getCharSequence(Notification.EXTRA_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_SUB_TEXT))?.toString() ?: ""

        // Notifikasi yang sama dikirim ulang berkali-kali (mis. update musik) diredam 3 detik.
        val sig = sbn.key + "|" + title + "|" + text
        val now = System.currentTimeMillis()
        if (sig == lastSig && now - lastTime < 3000) return
        lastSig = sig
        lastTime = now

        val prefix = when {
            isMedia -> "♪ "
            isTimer -> "⏱ "
            else -> ""
        }
        val icon = try {
            packageManager.getApplicationIcon(sbn.packageName)
        } catch (_: Exception) {
            null
        }
        IslandService.instance?.show(IslandInfo(prefix + title, text, icon, n.contentIntent))
    }
}
