package com.byhas.dynamicisland

import android.content.Context

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("island", Context.MODE_PRIVATE)

    var topOffset: Int
        get() = sp.getInt("top", 8)
        set(v) = sp.edit().putInt("top", v).apply()

    var collapsedW: Int
        get() = sp.getInt("cw", 110)
        set(v) = sp.edit().putInt("cw", v).apply()

    var expandedW: Int
        get() = sp.getInt("ew", 330)
        set(v) = sp.edit().putInt("ew", v).apply()

    /** Warna dasar island (ARGB, selalu opaque). Default: pastel lavender. */
    var bgColor: Int
        get() = sp.getInt("bg", 0xFFCDB4FF.toInt())
        set(v) = sp.edit().putInt("bg", v).apply()

    /** Opasitas island 40-100 (%). Makin kecil makin tembus/buram. */
    var opacity: Int
        get() = sp.getInt("op", 82)
        set(v) = sp.edit().putInt("op", v).apply()
}
