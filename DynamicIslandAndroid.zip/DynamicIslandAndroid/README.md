# Dynamic Island untuk Android

Aplikasi Android native (Kotlin) yang menampilkan Dynamic Island di atas semua aplikasi,
dengan animasi spring, warna pastel yang bisa diatur, dan tampilan semi-transparan ala kaca.

## Fitur
- Pill di area kamera/atas layar, melebar saat ada notifikasi lalu menyempit otomatis
- Menampilkan notifikasi, musik (♪), dan timer/alarm (⏱); ketuk island untuk membuka notifikasinya
- Warna kustom (preset pastel, slider corak/kepekatan/terang, atau kode hex) dan slider buram/tembus pandang
- Halaman pengaturan `app/src/main/assets/index.html` (dibuka di WebView di dalam aplikasi)

## Cara kerja ambil notifikasi
`IslandNotificationListener` adalah `NotificationListenerService`. Setelah pengguna memberi
**Akses notifikasi**, sistem Android memanggil `onNotificationPosted()` untuk setiap notifikasi baru.
Isinya (judul, teks, ikon aplikasi, aksi ketuk) diteruskan ke `IslandService` untuk digambar.
Semua diproses di HP, tidak ada data yang dikirim ke internet.

## Upload ke GitHub tanpa satu-satu
1. Buat repo baru, lalu **Add file > Create new file**, nama `.github/workflows/build.yml`, tempel isi `build.yml`, commit.
2. **Add file > Upload files**, upload **1 file zip** proyek ini, commit.
3. Tab **Actions** otomatis mengekstrak zip, memasukkan source ke repo, lalu build.
   APK muncul di **Releases** (`DynamicIsland.apk`).

## Catatan
- Android 8.0+ (minSdk 26)
- Android 13+ untuk APK di luar Play Store: izin Akses notifikasi mungkin terkunci sampai kamu memilih
  Info Aplikasi > titik tiga > **Izinkan setelan terbatas**
- Xiaomi/Oppo/Vivo: aktifkan autostart dan "tanpa batasan baterai" supaya service tidak dimatikan sistem
- Efek "buram" memakai warna semi-transparan bergradasi dan garis tepi tipis. Blur sungguhan terhadap
  isi layar di belakang island tidak didukung konsisten oleh overlay Android
